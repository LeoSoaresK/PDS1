/*Para executar, utilize os comandos " gcc alomundo.c -o alomundo " // "alomundo" no CMD

Leo Soares de Oliveira Junior - nº de registro 2021039492 
Data de realização: 17/10/2021

*/

#include <stdio.h> // para as entradas e saidas

int main ()
{
    printf("\n");
    printf("Alo mundo!");
    printf("\n");
    return 0;
}