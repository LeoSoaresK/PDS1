/*Para executar, utilize os comandos " gcc arquivos.c -o arquivos " // "arquivos" no CMD

Leo Soares de Oliveira Junior - nº de registro 2021039492 
Data de realização: 17/10/2021

*/

#include <stdio.h> // para as entradas e saidas
#include <stdlib.h> 

int main ()
{
    printf("\n");
    printf("%s", system("dir") );
    printf("\n");
    return 0;
}