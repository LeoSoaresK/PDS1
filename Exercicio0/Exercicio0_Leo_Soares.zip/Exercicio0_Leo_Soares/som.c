/*Para executar, utilize os comandos " gcc som.c -o som " // "som" no CMD

Leo Soares de Oliveira Junior - nº de registro 2021039492 
Data de realização: 17/10/2021

*/

#include <stdio.h> // para as entradas e saidas

int main ()
{
    printf("\n");
    printf("\a");
    return 0;
}