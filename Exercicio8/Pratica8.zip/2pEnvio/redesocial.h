  /*-------------------- redesocial.h ----------------------*/

#define NUM_PESSOAS 7

void inicializar_rede();

void adicionar_amizade(int i, int j);

float random_float();

void popularRedeSocialAleatoriamente(float P);

void imprimirRedeSocial();

int numAmigosEmComum(int v, int u);

